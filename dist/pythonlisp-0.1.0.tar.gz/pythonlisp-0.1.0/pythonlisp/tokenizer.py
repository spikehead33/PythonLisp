from typing import Generator, Tuple, Union
from collections import namedtuple, deque
from enum import Enum


Location = namedtuple("Location", ["lineno", "column"])
TokenKind = Enum("TokenKind",
                 ["LEFTPAR", "RIGHTPAR", "NUMBER", "STRING",
                  "SYMBOL", "SKIP", "NEWLINE", "UNKNOWN"])
Number = Union[int, float]
Value = str | Number | None
Lexeme = str
Token = Tuple[TokenKind, Lexeme, Value, Location]

LINE_BREAKS = " \t\n"


def isfloat(s: str) -> bool:
    try:
        float(s)
        return True
    except Exception:
        return False


def tokenize(source: str) -> Generator[Token, None, None]:
    skip = 0
    lineno, column = 1, 1
    for i, ch in enumerate(source):
        if skip > 0:
            skip -= 1
            continue
        kind = TokenKind.UNKNOWN
        value: Value = None
        lexeme = ""
        location = Location(lineno, column)
        if ch == "\n":
            lineno += 1
            column = 1
            continue
        elif ch in [" ", "\t"]:
            column += 1
            continue
        elif ch == "(":
            kind = TokenKind.LEFTPAR
            column += 1
            lexeme = ch
        elif ch == ")":
            kind = TokenKind.RIGHTPAR
            column += 1
            lexeme = ch
        elif ch == "\"":
            kind = TokenKind.STRING
            strbuffer: deque[str] = deque()
            for cursor in range(i, len(source)):
                column += 1
                strbuffer.append(source[cursor])
                if (len(strbuffer) > 1 and strbuffer[-2] != "\\"
                        and strbuffer[-1] == "\""):
                    break
                if source[cursor] == "\n":
                    lineno += 1
                    column = 1
            lexeme = ''.join(strbuffer)
            skip = len(lexeme) - 1
            strbuffer.popleft()
            strbuffer.pop()
            value = ''.join(strbuffer).replace("\\\"", "\"")
        else:  # Determine if the Token belongs to NUMBER/SYMBOL/UNKNOWN
            buffer: list[str] = []
            for cursor in range(i, len(source)):
                if (source[cursor] == "(" or source[cursor] == ")"
                        or source[cursor] in LINE_BREAKS):
                    break
                column += 1
                buffer.append(source[cursor])
            lexeme = ''.join(buffer)
            skip = len(lexeme) - 1

            try:
                value = float(lexeme)
            except ValueError:
                pass

            try:
                value = int(lexeme)
            except ValueError:
                pass

            if type(value) == int or type(value) == float:
                kind = TokenKind.NUMBER
            else:
                value = lexeme
                kind = TokenKind.SYMBOL
        yield (kind, lexeme, value, location)
