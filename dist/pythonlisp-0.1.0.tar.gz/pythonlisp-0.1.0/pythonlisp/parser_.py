"""EBNF for the language
SExp   := Atom
        | LeftParen SExp "." SExp RightParen  # This is a Pair
        | List
List   := LeftParen SExp < SExp > RightParen
Atom   := Number | String | Symbol
String := "\""[.\n]*"\""  # included in the Token
Number := Number  # included in the Token
Symbol := Symbol  # included in the Token
"""


def parse(lex):
    for token in lex:
        print(token)
